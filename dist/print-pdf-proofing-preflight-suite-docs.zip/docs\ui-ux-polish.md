# UI/UX Polish

## 見直し済み観点

- エラー、warning、passed を同じ report で比較できる。
- ユーザーは不足項目、推奨項目、次アクションを確認できる。
- Acrobat JavaScript + external evidence CLI では、検証結果を入力作業から離れた場所へ隠さない。

## 次の磨き込み

- 実ユーザーの手動テスト後、UI上の言葉を短くする。
- 長い項目名は折り返し、狭い画面でボタン内テキストが崩れないようにする。
- warning の解除理由を保存できるようにする。
